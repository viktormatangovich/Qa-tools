import{a as e,l as t,o as n}from"./locales.js";import{P as r,R as i}from"./CollapsiblePanel.js";import{t as a}from"./createLucideIcon.js";var o=typeof navigator<`u`,s=h(),c=_(),l=g(),u=typeof CSS>`u`||!CSS.supports?!1:CSS.supports(`-webkit-backdrop-filter:none`),d=s.platform===`MacIntel`&&s.maxTouchPoints>1||/iP(hone|ad|od)|iOS/.test(s.platform);o&&/firefox/i.test(l);var f=o&&/apple/i.test(navigator.vendor);o&&/Edg/i.test(l);var p=o&&/android/i.test(c)||/android/i.test(l);o&&c.toLowerCase().startsWith(`mac`)&&navigator.maxTouchPoints;var m=l.includes(`jsdom/`);function h(){if(!o)return{platform:``,maxTouchPoints:-1};let e=navigator.userAgentData;return e?.platform?{platform:e.platform,maxTouchPoints:navigator.maxTouchPoints}:{platform:navigator.platform??``,maxTouchPoints:navigator.maxTouchPoints??-1}}function g(){if(!o)return``;let e=navigator.userAgentData;return e&&Array.isArray(e.brands)?e.brands.map(({brand:e,version:t})=>`${e}/${t}`).join(` `):navigator.userAgent}function _(){if(!o)return``;let e=navigator.userAgentData;return e?.platform?e.platform:navigator.platform??``}var v=`data-base-ui-focusable`,y=`active`,b=`selected`,x=`ArrowLeft`,S=`ArrowRight`,ee=`ArrowUp`,te=`ArrowDown`;function ne(e){let t=e.activeElement;for(;t?.shadowRoot?.activeElement!=null;)t=t.shadowRoot.activeElement;return t}function re(e,t){if(!e||!t)return!1;let n=t.getRootNode?.();if(e.contains(t))return!0;if(n&&i(n)){let n=t;for(;n;){if(e===n)return!0;n=n.parentNode||n.host}}return!1}function ie(e){return`composedPath`in e?e.composedPath()[0]:e.target}function ae(e,t){if(t==null)return!1;if(`composedPath`in e)return e.composedPath().includes(t);let n=e;return n.target!=null&&t.contains(n.target)}function oe(e){return e.matches(`html,body`)}function se(e){return e?.ownerDocument||document}function ce(e){return r(e)&&e.matches(`input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])`)}function C(e){return e?e.getAttribute(`role`)===`combobox`&&ce(e):!1}function w(e){return e?e.hasAttribute(`data-base-ui-focusable`)?e:e.querySelector(`[data-base-ui-focusable]`)||e:null}function T(e){e.preventDefault(),e.stopPropagation()}function E(e){return`nativeEvent`in e}function D(e){return e.mozInputSource===0&&e.isTrusted?!0:p&&e.pointerType?e.type===`click`&&e.buttons===1:e.detail===0&&!e.pointerType}function O(e){return m?!1:!p&&e.width===0&&e.height===0||p&&e.width===1&&e.height===1&&e.pressure===0&&e.detail===0&&e.pointerType===`mouse`||e.width<1&&e.height<1&&e.pressure===0&&e.detail===0&&e.pointerType===`touch`}function k(e){let t=e.type;return t===`click`||t===`mousedown`||t===`keydown`||t===`keyup`}function A(e){return e?.ownerDocument||document}var j=`ArrowUp`,M=`ArrowDown`,N=`ArrowLeft`,P=`ArrowRight`,F=`Home`,I=new Set([N,P]),L=new Set([N,P,F,`End`]),R=new Set([j,M]),z=new Set([j,M,F,`End`]),B=new Set([...I,...R]),V=new Set([...B,F,`End`]),H=new Set([j,M,N,P,F,`End`]),U=new Set([`Shift`,`Control`,`Alt`,`Meta`]);function W(e){return r(e)&&e.tagName===`INPUT`}function G(e){return!!(W(e)&&e.selectionStart!=null||r(e)&&e.tagName===`TEXTAREA`)}function le(e,t,n,r){if(!e||!t||!t.scrollTo)return;let i=e.scrollLeft,a=e.scrollTop,o=e.clientWidth<e.scrollWidth,s=e.clientHeight<e.scrollHeight;if(o&&r!==`vertical`){let r=K(e,t,`left`),a=q(e),o=q(t);n===`ltr`&&(r+t.offsetWidth+o.scrollMarginRight>e.scrollLeft+e.clientWidth-a.scrollPaddingRight?i=r+t.offsetWidth+o.scrollMarginRight-e.clientWidth+a.scrollPaddingRight:r-o.scrollMarginLeft<e.scrollLeft+a.scrollPaddingLeft&&(i=r-o.scrollMarginLeft-a.scrollPaddingLeft)),n===`rtl`&&(r-o.scrollMarginRight<e.scrollLeft+a.scrollPaddingLeft?i=r-o.scrollMarginLeft-a.scrollPaddingLeft:r+t.offsetWidth+o.scrollMarginRight>e.scrollLeft+e.clientWidth-a.scrollPaddingRight&&(i=r+t.offsetWidth+o.scrollMarginRight-e.clientWidth+a.scrollPaddingRight))}if(s&&r!==`horizontal`){let n=K(e,t,`top`),r=q(e),i=q(t);n-i.scrollMarginTop<e.scrollTop+r.scrollPaddingTop?a=n-i.scrollMarginTop-r.scrollPaddingTop:n+t.offsetHeight+i.scrollMarginBottom>e.scrollTop+e.clientHeight-r.scrollPaddingBottom&&(a=n+t.offsetHeight+i.scrollMarginBottom-e.clientHeight+r.scrollPaddingBottom)}e.scrollTo({left:i,top:a,behavior:`auto`})}function K(e,t,n){let r=n===`left`?`offsetLeft`:`offsetTop`,i=0;for(;t.offsetParent&&(i+=t[r],t.offsetParent!==e);)t=t.offsetParent;return i}function q(e){let t=getComputedStyle(e);return{scrollMarginTop:parseFloat(t.scrollMarginTop)||0,scrollMarginRight:parseFloat(t.scrollMarginRight)||0,scrollMarginBottom:parseFloat(t.scrollMarginBottom)||0,scrollMarginLeft:parseFloat(t.scrollMarginLeft)||0,scrollPaddingTop:parseFloat(t.scrollPaddingTop)||0,scrollPaddingRight:parseFloat(t.scrollPaddingRight)||0,scrollPaddingBottom:parseFloat(t.scrollPaddingBottom)||0,scrollPaddingLeft:parseFloat(t.scrollPaddingLeft)||0}}var ue=a(`terminal`,[[`path`,{d:`M12 19h8`,key:`baeox8`}],[`path`,{d:`m4 17 6-6-6-6`,key:`1yngyt`}]]),J=t(n(),1),de=e();function fe(e){let t=(0,J.lazy)(async()=>({default:await e()}));return function(e){return(0,de.jsx)(J.Suspense,{fallback:null,children:(0,J.createElement)(t,e)})}}function pe(e){return e===null?`null`:Array.isArray(e)?`array`:typeof e}function Y(e){return e===0?`0 B`:e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:`${(e/(1024*1024)).toFixed(1)} MB`}function X(e){if(!e)return 0;try{let t=typeof e==`string`?e:JSON.stringify(e);return new Blob([t]).size}catch{return 0}}function Z(e){try{if(e==null)return`(пусто)`;if(typeof e==`string`)try{return JSON.stringify(JSON.parse(e),null,2)}catch{return e}return JSON.stringify(e,null,2)}catch{return String(e)}}function me(e){let t=e.status>=400||e.error,n=`## ${t?`Отчёт об ошибке API`:`Отчёт о запросе API`}

**Маршрут:** \`${e.method} ${e.url}\`
**Статус:** ${e.status} ${e.statusText}
**Длительность:** ${(e.duration/1e3).toFixed(2)}s
**Тип:** ${e.type.toUpperCase()}
${e.error?`**Ошибка:** ${e.error}`:``}

### Контекст страницы
- **URL:** ${e.pageUrl}
- **Заголовок:** ${e.pageTitle}

`;return e.requestBody&&(n+=`### Тело запроса
\`\`\`json
${Z(e.requestBody)}
\`\`\`

`),e.requestHeaders&&Object.keys(e.requestHeaders).length>0&&(n+=`### Заголовки запроса
\`\`\`
${Object.entries(e.requestHeaders).map(([e,t])=>`${e}: ${t}`).join(`
`)}
\`\`\`

`),n+=`### Тело ответа
\`\`\`json
${Z(e.responseBody)}
\`\`\`

`,e.responseHeaders&&Object.keys(e.responseHeaders).length>0&&(n+=`### Заголовки ответа
\`\`\`
${Object.entries(e.responseHeaders).map(([e,t])=>`${e}: ${t}`).join(`
`)}
\`\`\`

`),n+=`---
Помоги ${t?`разобраться с ошибкой API`:`проанализировать ответ API`}. ${t?`Что могло вызвать проблему и как её исправить?`:`Есть ли проблемы в этом запросе или ответе?`}
`,n}function he(e){let t=[`curl`];if(e.method!==`GET`&&t.push(`-X ${e.method}`),t.push(`'${e.url}'`),Object.entries(e.requestHeaders||{}).forEach(([e,n])=>{t.push(`-H '${e}: ${n}'`)}),e.requestBody){let n=typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody);t.push(`-d '${n.replace(/'/g,`\\'`)}'`)}return t.join(` \\
  `)}function ge(e){let t={method:e.method};Object.keys(e.requestHeaders||{}).length>0&&(t.headers=e.requestHeaders),e.requestBody&&(t.body=typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody));let n=JSON.stringify(t,null,2).replace(/"([^"]+)":/g,`$1:`);return`fetch('${e.url}', ${n})
  .then(res => res.json())
  .then(data => console.log(data))
  .catch(err => console.error(err))`}function _e(e){return{log:{version:`1.2`,creator:{name:`Reqpane`,version:typeof chrome<`u`&&chrome.runtime?.getManifest?chrome.runtime.getManifest().version:`dev`},entries:e.map(e=>({startedDateTime:new Date(e.timestamp).toISOString(),time:e.duration,_resourceType:e.type,request:{method:e.method,url:e.url,httpVersion:`HTTP/1.1`,headers:Object.entries(e.requestHeaders||{}).map(([e,t])=>({name:e,value:t})),queryString:[],cookies:[],headersSize:-1,bodySize:e.requestBody?new Blob([typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody)]).size:0,postData:e.requestBody?{mimeType:`application/json`,text:typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody)}:void 0},response:{status:e.status,statusText:e.statusText,httpVersion:`HTTP/1.1`,headers:Object.entries(e.responseHeaders||{}).map(([e,t])=>({name:e,value:t})),cookies:[],content:{size:e.responseBody?new Blob([typeof e.responseBody==`string`?e.responseBody:JSON.stringify(e.responseBody)]).size:0,mimeType:`application/json`,text:e.responseBody?typeof e.responseBody==`string`?e.responseBody:JSON.stringify(e.responseBody):``},redirectURL:``,headersSize:-1,bodySize:-1},cache:{},timings:e.timings?{blocked:e.timings.blocked,dns:e.timings.dns,connect:e.timings.connect+e.timings.ssl,ssl:e.timings.ssl,send:e.timings.send,wait:e.timings.wait,receive:e.timings.receive}:{send:0,wait:e.duration,receive:0}}))}}}function ve(e){return{info:{name:`Экспорт QA Tools - ${new Date().toISOString().slice(0,10)}`,schema:`https://schema.getpostman.com/json/collection/v2.1.0/collection.json`,description:`Экспорт из расширения QA Tools`},item:e.map(e=>{let t=(()=>{try{let t=new URL(e.url);return{raw:e.url,protocol:t.protocol.replace(`:`,``),host:t.hostname.split(`.`),path:t.pathname.split(`/`).filter(Boolean),query:Array.from(t.searchParams.entries()).map(([e,t])=>({key:e,value:t}))}}catch{return{raw:e.url}}})(),n={name:(()=>{try{return new URL(e.url).pathname||e.url}catch{return e.url}})(),request:{method:e.method,header:Object.entries(e.requestHeaders||{}).map(([e,t])=>({key:e,value:t,type:`text`})),url:t},response:[{name:`${e.status} ${e.statusText}`,status:e.statusText,code:e.status,header:Object.entries(e.responseHeaders||{}).map(([e,t])=>({key:e,value:t})),body:e.responseBody?typeof e.responseBody==`string`?e.responseBody:JSON.stringify(e.responseBody,null,2):``}]};return e.requestBody&&e.method!==`GET`&&(n.request.body={mode:`raw`,raw:typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody,null,2),options:{raw:{language:`json`}}}),n})}}function ye(e){let t=e.responseBody;if(!t)return`// Нет тела ответа для генерации типов`;let n;try{n=typeof t==`string`?JSON.parse(t):t}catch{return`// Нельзя создать типы: ответ содержит некорректный JSON`}function r(e,t,n=``){if(e===null)return`null`;if(e===void 0)return`undefined`;let a=typeof e;if(a===`string`)return`string`;if(a===`number`)return`number`;if(a===`boolean`)return`boolean`;if(Array.isArray(e))return e.length===0?`unknown[]`:`${r(e[0],t+`Item`,n)}[]`;if(a===`object`){let t=Object.entries(e);return t.length===0?`Record<string, unknown>`:`{\n${t.map(([e,t])=>{let a=r(t,i(e),n+`  `);return`${n}  ${/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(e)?e:`'${e}'`}: ${a}`}).join(`
`)}\n${n}}`}return`unknown`}function i(e){return e.charAt(0).toUpperCase()+e.slice(1)}try{return`interface ApiResponse ${r(n,`Response`,``)}`}catch{return`// Не удалось создать типы из ответа`}}function be(e){let t=e.length,n=e.filter(e=>e.status>=200&&e.status<300).length,r=e.filter(e=>e.status>=400&&e.status<500).length,i=e.filter(e=>e.status>=500).length,a=e.filter(e=>e.status===0||e.error).length,o=t>0?n/t*100:0,s=e.map(e=>e.duration),c=s.length>0?s.reduce((e,t)=>e+t,0)/s.length:0,l=s.length>0?Math.min(...s):0,u=s.length>0?Math.max(...s):0,d=e.reduce((e,t)=>e+X(t.requestBody)+X(t.responseBody),0),f={};return e.forEach(e=>{let t=e.status||0;f[t]=(f[t]||0)+1}),{total:t,successful:n,clientErrors:r,serverErrors:i,networkErrors:a,successRate:o,avgTime:c,minTime:l,maxTime:u,totalSize:d,statusDistribution:f,slowRequests:e.filter(e=>e.duration>500).sort((e,t)=>t.duration-e.duration)}}function xe(e,t,n){let r=be(e),i=`# Отчёт по API

**Сформирован:** ${new Date().toLocaleString()}
**Страница:** ${n.title||`Недоступно`}
**URL:** ${n.url||`Недоступно`}

---

## Сводка

| Показатель | Значение |
|--------|-------|
| Всего запросов | ${r.total} |
| Успешные (2xx) | ${r.successful} |
| Ошибки клиента (4xx) | ${r.clientErrors} |
| Ошибки сервера (5xx) | ${r.serverErrors} |
| Сетевые ошибки | ${r.networkErrors} |
| Доля успешных | ${r.successRate.toFixed(1)}% |
| Среднее время ответа | ${Math.round(r.avgTime)}ms |
| Минимальное время ответа | ${Math.round(r.minTime)}ms |
| Максимальное время ответа | ${Math.round(r.maxTime)}ms |
| Объём данных | ${Y(r.totalSize)} |

`,a=Object.keys(r.statusDistribution).map(Number).sort((e,t)=>e-t);a.length>0&&(i+=`### Распределение статусов

| Статус | Количество |
|--------|-------|
`,a.forEach(e=>{i+=`| ${e||`ERR`} | ${r.statusDistribution[e]} |\n`}),i+=`
`),r.slowRequests.length>0&&(i+=`### Медленные запросы (>500 мс)

| URL | Метод | Время | Статус |
|-----|--------|----------|--------|
`,r.slowRequests.slice(0,10).forEach(e=>{let t=e.url;try{t=new URL(e.url).pathname,t.length>50&&(t=`...`+t.slice(-47))}catch{}i+=`| ${t} | ${e.method} | ${e.duration}ms | ${e.status||`ERR`} |\n`}),i+=`
`);let o=e.filter(e=>e.status>=400||e.error);return o.length>0&&(i+=`---

## Неуспешные запросы (${o.length})

`,o.forEach((e,t)=>{let n=e.url;try{n=new URL(e.url).pathname}catch{}i+=`### ${t+1}. ${e.method} ${n}

- **Статус:** ${e.status} ${e.statusText||``}
- **Длительность:** ${e.duration}ms
- **Время:** ${new Date(e.timestamp).toLocaleTimeString()}
${e.error?`- **Ошибка:** ${e.error}`:``}

`,e.responseBody&&(i+=`**Ответ:**
\`\`\`json
${Z(e.responseBody)}
\`\`\`

`)})),i+=`---

## Все запросы (${e.length})

`,e.forEach(e=>{let t=e.url;try{t=new URL(e.url).pathname}catch{}if(i+=`### ${e.method} ${t}

- **Статус:** ${e.status} ${e.statusText||``}
- **Длительность:** ${e.duration}ms
- **Время:** ${new Date(e.timestamp).toLocaleTimeString()}

`,e.requestHeaders&&Object.keys(e.requestHeaders).length>0&&(i+=`**Заголовки запроса:**
\`\`\`
${Object.entries(e.requestHeaders).map(([e,t])=>`${e}: ${[`authorization`,`cookie`,`x-api-key`].includes(e.toLowerCase())?t.slice(0,10)+`...`:t}`).join(`
`)}
\`\`\`

`),e.requestBody&&(i+=`**Тело запроса:**
\`\`\`json
${Z(e.requestBody)}
\`\`\`

`),e.responseHeaders&&Object.keys(e.responseHeaders).length>0&&(i+=`**Заголовки ответа:**
\`\`\`
${Object.entries(e.responseHeaders).map(([e,t])=>`${e}: ${t}`).join(`
`)}
\`\`\`

`),e.responseBody){let t=Z(e.responseBody),n=t.length>2e3?t.slice(0,2e3)+`
... (сокращено)`:t;i+=`**Тело ответа:**
\`\`\`json
${n}
\`\`\`

`}}),t.length>0&&(i+=`---

## Ошибки консоли (${t.length})

`,t.forEach((e,t)=>{i+=`### ${t+1}. ${e.message.slice(0,100)}${e.message.length>100?`...`:``}

- **Тип:** ${e.type}
${e.filename?`- **Файл:** ${e.filename}${e.lineno?`:${e.lineno}`:``}${e.colno?`:${e.colno}`:``}`:``}
- **Время:** ${new Date(e.timestamp).toLocaleTimeString()}

`,e.stack&&(i+=`**Стек вызовов:**
\`\`\`
${e.stack}
\`\`\`

`)})),i+=`---

*Отчёт сформирован расширением QA Tools*
`,i}async function Se(){let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e?.id}async function Q(e,t){try{await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:t})}catch{await chrome.scripting.executeScript({target:{tabId:e},files:t})}}async function Ce(e,t={}){let n=await Se();if(n===void 0)return;let r=t.allFrames?void 0:{frameId:0},i=()=>r?chrome.tabs.sendMessage(n,e,r):chrome.tabs.sendMessage(n,e);t.inject?.length&&await Q(n,t.inject);try{return await i()}catch{return await Q(n,[`content.js`]),await i()}}var we=`modulepreload`,Te=function(e){return`/`+e},$={},Ee=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=Te(t,n),t=s(t),t in $)return;$[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:we,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})};export{u as $,A,ie as B,I as C,z as D,R as E,T as F,te as G,oe as H,ne as I,ee as J,x as K,re as L,E as M,D as N,G as O,O as P,f as Q,se as R,F as S,U as T,C as U,ae as V,y as W,b as X,v as Y,d as Z,B as _,ge as a,j as b,ve as c,X as d,pe as f,M as g,V as h,he as i,k as j,le as k,ye as l,ue as m,Ce as n,_e as o,fe as p,S as q,me as r,xe as s,Ee as t,Y as u,N as v,L as w,H as x,P as y,w as z};
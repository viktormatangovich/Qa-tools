import{a as e,l as t,o as n}from"./locales.js";import{A as r,E as i}from"./useOpenChangeComplete.js";import{t as a}from"./createLucideIcon.js";import{t as o}from"./messages.js";var s=a(`bell-ring`,[[`path`,{d:`M10.268 21a2 2 0 0 0 3.464 0`,key:`vwvbt9`}],[`path`,{d:`M22 8c0-2.3-.8-4.3-2-6`,key:`5bb3ad`}],[`path`,{d:`M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326`,key:`11g9vi`}],[`path`,{d:`M4 2C2.8 3.7 2 5.7 2 8`,key:`tap9e0`}]]),c=a(`notebook-pen`,[[`path`,{d:`M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4`,key:`re6nr2`}],[`path`,{d:`M2 6h4`,key:`aawbzj`}],[`path`,{d:`M2 10h4`,key:`l0bgd4`}],[`path`,{d:`M2 14h4`,key:`1gsvsf`}],[`path`,{d:`M2 18h4`,key:`1bu2t1`}],[`path`,{d:`M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z`,key:`pqwjuv`}]]),l=a(`terminal`,[[`path`,{d:`M12 19h8`,key:`baeox8`}],[`path`,{d:`m4 17 6-6-6-6`,key:`1yngyt`}]]),u=typeof navigator<`u`,d=_(),f=y(),p=v(),ee=typeof CSS>`u`||!CSS.supports?!1:CSS.supports(`-webkit-backdrop-filter:none`),te=d.platform===`MacIntel`&&d.maxTouchPoints>1||/iP(hone|ad|od)|iOS/.test(d.platform);u&&/firefox/i.test(p);var m=u&&/apple/i.test(navigator.vendor);u&&/Edg/i.test(p);var h=u&&/android/i.test(f)||/android/i.test(p);u&&f.toLowerCase().startsWith(`mac`)&&navigator.maxTouchPoints;var g=p.includes(`jsdom/`);function _(){if(!u)return{platform:``,maxTouchPoints:-1};let e=navigator.userAgentData;return e?.platform?{platform:e.platform,maxTouchPoints:navigator.maxTouchPoints}:{platform:navigator.platform??``,maxTouchPoints:navigator.maxTouchPoints??-1}}function v(){if(!u)return``;let e=navigator.userAgentData;return e&&Array.isArray(e.brands)?e.brands.map(({brand:e,version:t})=>`${e}/${t}`).join(` `):navigator.userAgent}function y(){if(!u)return``;let e=navigator.userAgentData;return e?.platform?e.platform:navigator.platform??``}var b=`data-base-ui-focusable`,x=`active`,S=`selected`,ne=`ArrowLeft`,re=`ArrowRight`,ie=`ArrowUp`,ae=`ArrowDown`;function oe(e){let t=e.activeElement;for(;t?.shadowRoot?.activeElement!=null;)t=t.shadowRoot.activeElement;return t}function se(e,t){if(!e||!t)return!1;let n=t.getRootNode?.();if(e.contains(t))return!0;if(n&&r(n)){let n=t;for(;n;){if(e===n)return!0;n=n.parentNode||n.host}}return!1}function ce(e){return`composedPath`in e?e.composedPath()[0]:e.target}function le(e,t){if(t==null)return!1;if(`composedPath`in e)return e.composedPath().includes(t);let n=e;return n.target!=null&&t.contains(n.target)}function ue(e){return e.matches(`html,body`)}function de(e){return e?.ownerDocument||document}function fe(e){return i(e)&&e.matches(`input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])`)}function pe(e){return e?e.getAttribute(`role`)===`combobox`&&fe(e):!1}function me(e){return e?e.hasAttribute(`data-base-ui-focusable`)?e:e.querySelector(`[data-base-ui-focusable]`)||e:null}function C(e){e.preventDefault(),e.stopPropagation()}function w(e){return`nativeEvent`in e}function T(e){return e.mozInputSource===0&&e.isTrusted?!0:h&&e.pointerType?e.type===`click`&&e.buttons===1:e.detail===0&&!e.pointerType}function E(e){return g?!1:!h&&e.width===0&&e.height===0||h&&e.width===1&&e.height===1&&e.pressure===0&&e.detail===0&&e.pointerType===`mouse`||e.width<1&&e.height<1&&e.pressure===0&&e.detail===0&&e.pointerType===`touch`}function D(e){let t=e.type;return t===`click`||t===`mousedown`||t===`keydown`||t===`keyup`}function O(e){return e?.ownerDocument||document}var k=`ArrowUp`,A=`ArrowDown`,j=`ArrowLeft`,M=`ArrowRight`,N=`Home`,P=new Set([j,M]),F=new Set([j,M,N,`End`]),I=new Set([k,A]),L=new Set([k,A,N,`End`]),R=new Set([...P,...I]),z=new Set([...R,N,`End`]),he=new Set([k,A,j,M,N,`End`]),ge=new Set([`Shift`,`Control`,`Alt`,`Meta`]);function _e(e){return i(e)&&e.tagName===`INPUT`}function B(e){return!!(_e(e)&&e.selectionStart!=null||i(e)&&e.tagName===`TEXTAREA`)}function ve(e,t,n,r){if(!e||!t||!t.scrollTo)return;let i=e.scrollLeft,a=e.scrollTop,o=e.clientWidth<e.scrollWidth,s=e.clientHeight<e.scrollHeight;if(o&&r!==`vertical`){let r=V(e,t,`left`),a=H(e),o=H(t);n===`ltr`&&(r+t.offsetWidth+o.scrollMarginRight>e.scrollLeft+e.clientWidth-a.scrollPaddingRight?i=r+t.offsetWidth+o.scrollMarginRight-e.clientWidth+a.scrollPaddingRight:r-o.scrollMarginLeft<e.scrollLeft+a.scrollPaddingLeft&&(i=r-o.scrollMarginLeft-a.scrollPaddingLeft)),n===`rtl`&&(r-o.scrollMarginRight<e.scrollLeft+a.scrollPaddingLeft?i=r-o.scrollMarginLeft-a.scrollPaddingLeft:r+t.offsetWidth+o.scrollMarginRight>e.scrollLeft+e.clientWidth-a.scrollPaddingRight&&(i=r+t.offsetWidth+o.scrollMarginRight-e.clientWidth+a.scrollPaddingRight))}if(s&&r!==`horizontal`){let n=V(e,t,`top`),r=H(e),i=H(t);n-i.scrollMarginTop<e.scrollTop+r.scrollPaddingTop?a=n-i.scrollMarginTop-r.scrollPaddingTop:n+t.offsetHeight+i.scrollMarginBottom>e.scrollTop+e.clientHeight-r.scrollPaddingBottom&&(a=n+t.offsetHeight+i.scrollMarginBottom-e.clientHeight+r.scrollPaddingBottom)}e.scrollTo({left:i,top:a,behavior:`auto`})}function V(e,t,n){let r=n===`left`?`offsetLeft`:`offsetTop`,i=0;for(;t.offsetParent&&(i+=t[r],t.offsetParent!==e);)t=t.offsetParent;return i}function H(e){let t=getComputedStyle(e);return{scrollMarginTop:parseFloat(t.scrollMarginTop)||0,scrollMarginRight:parseFloat(t.scrollMarginRight)||0,scrollMarginBottom:parseFloat(t.scrollMarginBottom)||0,scrollMarginLeft:parseFloat(t.scrollMarginLeft)||0,scrollPaddingTop:parseFloat(t.scrollPaddingTop)||0,scrollPaddingRight:parseFloat(t.scrollPaddingRight)||0,scrollPaddingBottom:parseFloat(t.scrollPaddingBottom)||0,scrollPaddingLeft:parseFloat(t.scrollPaddingLeft)||0}}function ye(e){return e===null?`null`:typeof e==`object`?null:String(e)}function U(e,t,n){if(!n)return{key:!1,value:!1};let r=typeof e==`string`&&e.toLowerCase().includes(n),i=ye(t);return{key:r,value:i!==null&&i.toLowerCase().includes(n)}}function be(e,t){let n=t.trim().toLowerCase(),r={paths:[],ancestors:new Set};if(!n)return r;let i=(e,t,a,o)=>{let s=U(e,t,n);if(s.key||s.value){r.paths.push(a);for(let e of o)r.ancestors.add(e)}if(t&&typeof t==`object`){let e=Array.isArray(t),n=[...o,a];Object.entries(t).forEach(([t,r],o)=>{i(e?o:t,r,`${a}.${t}`,n)})}};return i(null,e,`root`,[]),r}var W=t(n(),1),xe=e();function Se(e){let t=(0,W.lazy)(async()=>({default:await e()}));return function(e){return(0,xe.jsx)(W.Suspense,{fallback:null,children:(0,W.createElement)(t,e)})}}function Ce(e){return e===null?`null`:Array.isArray(e)?`array`:typeof e}function G(e){return e===0?`0 B`:e<1024?`${e} B`:e<1024*1024?`${(e/1024).toFixed(1)} KB`:`${(e/(1024*1024)).toFixed(1)} MB`}function K(e){if(!e)return 0;try{let t=typeof e==`string`?e:JSON.stringify(e);return new Blob([t]).size}catch{return 0}}function q(e){try{if(e==null)return o().empty;if(typeof e==`string`)try{return JSON.stringify(JSON.parse(e),null,2)}catch{return e}return JSON.stringify(e,null,2)}catch{return String(e)}}function we(e){let t=e.status>=400||e.error,n=o(),r=`## ${t?n.promptErrorTitle:n.promptRequestTitle}

**${n.promptRoute}:** \`${e.method} ${e.url}\`
**${n.promptStatus}:** ${e.status} ${e.statusText}
**${n.promptDuration}:** ${(e.duration/1e3).toFixed(2)}s
**${n.promptType}:** ${e.type.toUpperCase()}
${e.error?`**${n.promptError}:** ${e.error}`:``}

### ${n.promptPageContext}
- **URL:** ${e.pageUrl}
- **${n.promptPageTitle}:** ${e.pageTitle}

`;return e.requestBody&&(r+=`### ${n.requestBody}
\`\`\`json
${q(e.requestBody)}
\`\`\`

`),e.requestHeaders&&Object.keys(e.requestHeaders).length>0&&(r+=`### ${n.requestHeaders}
\`\`\`
${Object.entries(e.requestHeaders).map(([e,t])=>`${e}: ${t}`).join(`
`)}
\`\`\`

`),r+=`### ${n.responseBody}
\`\`\`json
${q(e.responseBody)}
\`\`\`

`,e.responseHeaders&&Object.keys(e.responseHeaders).length>0&&(r+=`### ${n.responseHeaders}
\`\`\`
${Object.entries(e.responseHeaders).map(([e,t])=>`${e}: ${t}`).join(`
`)}
\`\`\`

`),r+=`---
${t?n.promptAskError:n.promptAskRequest}
`,r}function Te(e){let t=[`curl`];if(e.method!==`GET`&&t.push(`-X ${e.method}`),t.push(`'${e.url}'`),Object.entries(e.requestHeaders||{}).forEach(([e,n])=>{t.push(`-H '${e}: ${n}'`)}),e.requestBody){let n=typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody);t.push(`-d '${n.replace(/'/g,`\\'`)}'`)}return t.join(` \\
  `)}function Ee(e){let t={method:e.method};Object.keys(e.requestHeaders||{}).length>0&&(t.headers=e.requestHeaders),e.requestBody&&(t.body=typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody));let n=JSON.stringify(t,null,2).replace(/"([^"]+)":/g,`$1:`);return`fetch('${e.url}', ${n})
  .then(res => res.json())
  .then(data => console.log(data))
  .catch(err => console.error(err))`}function De(e){return{log:{version:`1.2`,creator:{name:`Reqpane`,version:typeof chrome<`u`&&chrome.runtime?.getManifest?chrome.runtime.getManifest().version:`dev`},entries:e.map(e=>({startedDateTime:new Date(e.timestamp).toISOString(),time:e.duration,_resourceType:e.type,request:{method:e.method,url:e.url,httpVersion:`HTTP/1.1`,headers:Object.entries(e.requestHeaders||{}).map(([e,t])=>({name:e,value:t})),queryString:[],cookies:[],headersSize:-1,bodySize:e.requestBody?new Blob([typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody)]).size:0,postData:e.requestBody?{mimeType:`application/json`,text:typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody)}:void 0},response:{status:e.status,statusText:e.statusText,httpVersion:`HTTP/1.1`,headers:Object.entries(e.responseHeaders||{}).map(([e,t])=>({name:e,value:t})),cookies:[],content:{size:e.responseBody?new Blob([typeof e.responseBody==`string`?e.responseBody:JSON.stringify(e.responseBody)]).size:0,mimeType:`application/json`,text:e.responseBody?typeof e.responseBody==`string`?e.responseBody:JSON.stringify(e.responseBody):``},redirectURL:``,headersSize:-1,bodySize:-1},cache:{},timings:e.timings?{blocked:e.timings.blocked,dns:e.timings.dns,connect:e.timings.connect+e.timings.ssl,ssl:e.timings.ssl,send:e.timings.send,wait:e.timings.wait,receive:e.timings.receive}:{send:0,wait:e.duration,receive:0},...e.note?{comment:e.note}:{}}))}}}function Oe(e){return{info:{name:o().postmanName(new Date().toISOString().slice(0,10)),schema:`https://schema.getpostman.com/json/collection/v2.1.0/collection.json`,description:o().postmanDescription},item:e.map(e=>{let t=(()=>{try{let t=new URL(e.url);return{raw:e.url,protocol:t.protocol.replace(`:`,``),host:t.hostname.split(`.`),path:t.pathname.split(`/`).filter(Boolean),query:Array.from(t.searchParams.entries()).map(([e,t])=>({key:e,value:t}))}}catch{return{raw:e.url}}})(),n={name:(()=>{try{return new URL(e.url).pathname||e.url}catch{return e.url}})(),request:{method:e.method,header:Object.entries(e.requestHeaders||{}).map(([e,t])=>({key:e,value:t,type:`text`})),url:t},response:[{name:`${e.status} ${e.statusText}`,status:e.statusText,code:e.status,header:Object.entries(e.responseHeaders||{}).map(([e,t])=>({key:e,value:t})),body:e.responseBody?typeof e.responseBody==`string`?e.responseBody:JSON.stringify(e.responseBody,null,2):``}]};return e.requestBody&&e.method!==`GET`&&(n.request.body={mode:`raw`,raw:typeof e.requestBody==`string`?e.requestBody:JSON.stringify(e.requestBody,null,2),options:{raw:{language:`json`}}}),n})}}function ke(e){let t=e.responseBody;if(!t)return o().tsNoBody;let n;try{n=typeof t==`string`?JSON.parse(t):t}catch{return o().tsInvalidJson}function r(e,t,n=``){if(e===null)return`null`;if(e===void 0)return`undefined`;let a=typeof e;if(a===`string`)return`string`;if(a===`number`)return`number`;if(a===`boolean`)return`boolean`;if(Array.isArray(e))return e.length===0?`unknown[]`:`${r(e[0],t+`Item`,n)}[]`;if(a===`object`){let t=Object.entries(e);return t.length===0?`Record<string, unknown>`:`{\n${t.map(([e,t])=>{let a=r(t,i(e),n+`  `);return`${n}  ${/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(e)?e:`'${e}'`}: ${a}`}).join(`
`)}\n${n}}`}return`unknown`}function i(e){return e.charAt(0).toUpperCase()+e.slice(1)}try{return`interface ApiResponse ${r(n,`Response`,``)}`}catch{return o().tsFailed}}function Ae(e){let t=e.length,n=e.filter(e=>e.status>=200&&e.status<300).length,r=e.filter(e=>e.status>=400&&e.status<500).length,i=e.filter(e=>e.status>=500).length,a=e.filter(e=>e.status===0||e.error).length,o=t>0?n/t*100:0,s=e.map(e=>e.duration),c=s.length>0?s.reduce((e,t)=>e+t,0)/s.length:0,l=s.length>0?Math.min(...s):0,u=s.length>0?Math.max(...s):0,d=e.reduce((e,t)=>e+K(t.requestBody)+K(t.responseBody),0),f={};return e.forEach(e=>{let t=e.status||0;f[t]=(f[t]||0)+1}),{total:t,successful:n,clientErrors:r,serverErrors:i,networkErrors:a,successRate:o,avgTime:c,minTime:l,maxTime:u,totalSize:d,statusDistribution:f,slowRequests:e.filter(e=>e.duration>500).sort((e,t)=>t.duration-e.duration)}}function je(e,t,n){let r=o(),i=Ae(e),a=new Date().toLocaleString(),s=e=>e.note?.trim()?`- **${r.note}:** ${e.note.trim()}\n`:``,c=`# ${r.mdTitle}

**${r.mdGenerated}:** ${a}
**${r.mdPage}:** ${n.title||r.notAvailable}
**URL:** ${n.url||r.notAvailable}

---

## ${r.mdSummary}

| ${r.mdMetric} | ${r.mdValue} |
|--------|-------|
| ${r.mdTotal} | ${i.total} |
| ${r.mdSuccessful} | ${i.successful} |
| ${r.mdClientErrors} | ${i.clientErrors} |
| ${r.mdServerErrors} | ${i.serverErrors} |
| ${r.mdNetworkErrors} | ${i.networkErrors} |
| ${r.mdSuccessRate} | ${i.successRate.toFixed(1)}% |
| ${r.mdAvgTime} | ${Math.round(i.avgTime)}ms |
| ${r.mdMinTime} | ${Math.round(i.minTime)}ms |
| ${r.mdMaxTime} | ${Math.round(i.maxTime)}ms |
| ${r.mdDataSize} | ${G(i.totalSize)} |

`,l=Object.keys(i.statusDistribution).map(Number).sort((e,t)=>e-t);l.length>0&&(c+=`### ${r.mdStatusDistribution}

| ${r.mdStatus} | ${r.mdCount} |
|--------|-------|
`,l.forEach(e=>{c+=`| ${e||`ERR`} | ${i.statusDistribution[e]} |\n`}),c+=`
`),i.slowRequests.length>0&&(c+=`### ${r.mdSlowRequests}

| URL | ${r.mdMethod} | ${r.mdTime} | ${r.mdStatus} |
|-----|--------|----------|--------|
`,i.slowRequests.slice(0,10).forEach(e=>{let t=e.url;try{t=new URL(e.url).pathname,t.length>50&&(t=`...`+t.slice(-47))}catch{}c+=`| ${t} | ${e.method} | ${e.duration}ms | ${e.status||`ERR`} |\n`}),c+=`
`);let u=e.filter(e=>e.status>=400||e.error);return u.length>0&&(c+=`---

## ${r.mdFailedRequests(u.length)}

`,u.forEach((e,t)=>{let n=e.url;try{n=new URL(e.url).pathname}catch{}c+=`### ${t+1}. ${e.method} ${n}

- **${r.mdStatus}:** ${e.status} ${e.statusText||``}
- **${r.mdDuration}:** ${e.duration}ms
- **${r.mdTime}:** ${new Date(e.timestamp).toLocaleTimeString()}
${e.error?`- **${r.mdError}:** ${e.error}`:``}
${s(e)}
`,e.responseBody&&(c+=`**${r.mdResponse}:**
\`\`\`json
${q(e.responseBody)}
\`\`\`

`)})),c+=`---

## ${r.mdAllRequests(e.length)}

`,e.forEach(e=>{let t=e.url;try{t=new URL(e.url).pathname}catch{}if(c+=`### ${e.method} ${t}

- **${r.mdStatus}:** ${e.status} ${e.statusText||``}
- **${r.mdDuration}:** ${e.duration}ms
- **${r.mdTime}:** ${new Date(e.timestamp).toLocaleTimeString()}
${s(e)}
`,e.requestHeaders&&Object.keys(e.requestHeaders).length>0&&(c+=`**${r.requestHeaders}:**
\`\`\`
${Object.entries(e.requestHeaders).map(([e,t])=>`${e}: ${[`authorization`,`cookie`,`x-api-key`].includes(e.toLowerCase())?t.slice(0,10)+`...`:t}`).join(`
`)}
\`\`\`

`),e.requestBody&&(c+=`**${r.requestBody}:**
\`\`\`json
${q(e.requestBody)}
\`\`\`

`),e.responseHeaders&&Object.keys(e.responseHeaders).length>0&&(c+=`**${r.responseHeaders}:**
\`\`\`
${Object.entries(e.responseHeaders).map(([e,t])=>`${e}: ${t}`).join(`
`)}
\`\`\`

`),e.responseBody){let t=q(e.responseBody),n=t.length>2e3?t.slice(0,2e3)+`
`+r.mdTruncated:t;c+=`**${r.responseBody}:**
\`\`\`json
${n}
\`\`\`

`}}),t.length>0&&(c+=`---

## ${r.mdConsoleErrors(t.length)}

`,t.forEach((e,t)=>{c+=`### ${t+1}. ${e.message.slice(0,100)}${e.message.length>100?`...`:``}

- **${r.mdType}:** ${e.type}
${e.filename?`- **${r.mdFile}:** ${e.filename}${e.lineno?`:${e.lineno}`:``}${e.colno?`:${e.colno}`:``}`:``}
- **${r.mdTime}:** ${new Date(e.timestamp).toLocaleTimeString()}

`,e.stack&&(c+=`**${r.mdStack}:**
\`\`\`
${e.stack}
\`\`\`

`)})),c+=`---

${r.mdFooter}
`,c}async function Me(){let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e?.id}async function J(e,t){try{await chrome.scripting.executeScript({target:{tabId:e,allFrames:!0},files:t})}catch{await chrome.scripting.executeScript({target:{tabId:e},files:t})}}async function Ne(e,t={}){let n=await Me();if(n===void 0)return;let r=t.allFrames?void 0:{frameId:0},i=()=>r?chrome.tabs.sendMessage(n,e,r):chrome.tabs.sendMessage(n,e);t.inject?.length&&await J(n,t.inject);try{return await i()}catch{return await J(n,[`content.js`]),await i()}}var Pe=`modulepreload`,Fe=function(e){return`/`+e},Y={},Ie=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=Fe(t,n),t=s(t),t in Y)return;Y[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:Pe,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})};function X(e){let t=e.url;try{t=new URL(e.url).pathname}catch{t=e.url.split(`?`)[0]}return`${e.method} ${t.replace(/\/(?:\d+|[0-9a-f]{8}-[0-9a-f-]{27,})(?=\/|$)/gi,`/{id}`)}`}var Z=40,Le=8,Q=e=>e===null?`null`:Array.isArray(e)?`array`:typeof e;function $(e,t,n=``,r=[],i=0,a=!1){if(r.length>=Z||i>Le)return r;let o=Q(e),s=Q(t),c=n||`(body)`;if(o!==s)return r.push({path:c,kind:`type`,before:o,after:s}),r;if(s===`array`){let a=e,o=t;return a.length!==o.length&&r.push({path:`${c}.length`,kind:`length`,before:a.length,after:o.length}),a.length&&o.length&&$(a[0],o[0],`${n}[0]`,r,i+1,!0),r}if(s===`object`){let o=e,s=t;for(let e of Object.keys(o)){if(r.length>=Z)break;let t=n?`${n}.${e}`:e;e in s?$(o[e],s[e],t,r,i+1,a):r.push({path:t,kind:`removed`,before:o[e]})}for(let e of Object.keys(s)){if(r.length>=Z)break;e in o||r.push({path:n?`${n}.${e}`:e,kind:`added`,after:s[e]})}return r}return!a&&e!==t&&r.push({path:c,kind:`changed`,before:e,after:t}),r}function Re(e){if(typeof e!=`string`)return e;try{return JSON.parse(e)}catch{return e}}function ze(e,t){let n=X(t),r=e.filter(e=>!e.id.startsWith(`stream:`)&&X(e)===n).sort((e,t)=>e.timestamp-t.timestamp),i,a,o=r.map(e=>{let t=Re(e.responseBody),n=t!=null&&t!==``,r=n&&i!==void 0?$(i,t):[],o=a!==void 0&&a!==e.status;return n&&(i=t),a=e.status,{request:e,changes:r,statusChanged:o}}),s=r.map(e=>e.duration||0);return{key:n,entries:o,stats:{count:r.length,errors:r.filter(e=>e.status>=400||e.status===0||!!e.error).length,minMs:s.length?Math.min(...s):0,maxMs:s.length?Math.max(...s):0,avgMs:s.length?Math.round(s.reduce((e,t)=>e+t,0)/s.length):0,statuses:[...new Set(r.map(e=>e.status))].sort((e,t)=>e-t)}}}export{S as $,L as A,se as B,k as C,F as D,P as E,w as F,ue as G,me as H,T as I,ae as J,pe as K,E as L,ve as M,O as N,ge as O,D as P,b as Q,C as R,M as S,N as T,ce as U,de as V,le as W,re as X,ne as Y,ie as Z,be as _,we as a,s as at,R as b,De as c,ke as d,te as et,G as f,U as g,Se as h,Ne as i,c as it,B as j,I as k,je as l,Ce as m,X as n,ee as nt,Te as o,K as p,x as q,Ie as r,l as rt,Ee as s,ze as t,m as tt,Oe as u,z as v,he as w,j as x,A as y,oe as z};